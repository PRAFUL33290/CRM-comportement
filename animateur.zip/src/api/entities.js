import { base44 } from './base44Client';


export const Enfant = base44.entities.Enfant;

export const Evenement = base44.entities.Evenement;

export const MessageMur = base44.entities.MessageMur;



// auth sdk:
export const User = base44.auth;